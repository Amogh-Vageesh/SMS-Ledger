#!/usr/bin/env python3
"""Build the Kosha web edition (iPhone) from the Android app's index.html.
usage: mkweb.py <android index.html> <out dir> <version>"""
import sys, os, re, shutil, json, hashlib
src, out, ver = sys.argv[1], sys.argv[2], sys.argv[3]
here = os.path.dirname(os.path.abspath(__file__))
FB = os.path.join(here, "src", "firebase")
html = open(src, encoding="utf-8").read()

# 0) iPhone touches run inside the app (same place the app's own add-ons go)
marker = "\nconnectDb();\n})();"
if "window.koshaPasteSms" not in html:
    assert html.count(marker) == 1, "app end marker not found"
    post = open(os.path.join(here, "src", "post.js"), encoding="utf-8").read()
    acct = "" if "window.__koshaAcct" in html else open(os.path.join(here, "src", "acct.js"), encoding="utf-8").read()
    html = html.replace(marker, "\n" + acct + "\n" + post + marker, 1)

# 1) head: iPhone app metadata
head_add = """
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="Kosha">
<meta name="apple-mobile-web-app-status-bar-style" content="default">
<meta name="theme-color" content="#fff8ec">
<meta name="format-detection" content="telephone=no">
"""
html = html.replace("</head>", head_add + "</head>", 1)

# 2) the main app script waits until the ledger is loaded from IndexedDB
n = html.count("\n<script>\n")
assert n == 1, "expected one main <script>, found %d" % n
html = html.replace("\n<script>\n", '\n<script type="text/kosha-app" id="koshaApp">\n', 1)
libs = open(os.path.join(here, "test", "fakefb.js"), encoding="utf-8").read() if os.environ.get("KOSHA_FAKEFB") else "".join(open(os.path.join(FB, f), encoding="utf-8").read().replace("</script", "<\\/script") + "\n"
               for f in ["firebase-app-compat.js", "firebase-auth-compat.js", "firebase-firestore-compat.js"])
bridge = open(os.path.join(here, "src", "bridge.js"), encoding="utf-8").read()
loader = """
<script>
%s
</script>
<script>
%s
</script>
<script>
(function(){
  function run(id){ var t = document.getElementById(id); if(!t) return; var s = document.createElement("script"); s.textContent = t.textContent; t.parentNode.insertBefore(s, t.nextSibling); t.remove(); }
  window.__koshaBoot(function(){ run("koshaApp"); });
  if("serviceWorker" in navigator) window.addEventListener("load", function(){ navigator.serviceWorker.register("sw.js").catch(function(){}); });
})();
</script>
""" % (libs, bridge)
# put the loader after the (now inert) main script
i = html.index('<script type="text/kosha-app" id="koshaApp">')
j = html.index("\n</script>", i) + len("\n</script>")
html = html[:j] + loader + html[j:]
html = html.replace("<title>", "<title>", 1)

os.makedirs(out, exist_ok=True)
open(os.path.join(out, "index.html"), "w", encoding="utf-8").write(html)

# 3) OCR assets, icons, manifest, service worker
app_dir = os.path.dirname(os.path.abspath(src))
if os.path.isdir(os.path.join(app_dir, "ocr")):
    shutil.copytree(os.path.join(app_dir, "ocr"), os.path.join(out, "ocr"), dirs_exist_ok=True)
for f in ["icon-192.png", "icon-512.png", "apple-touch-icon.png"]:
    p = os.path.join(here, "icons", f)
    if os.path.exists(p) and os.path.abspath(p) != os.path.abspath(os.path.join(out, f)): shutil.copy(p, out)
json.dump({"name": "Kosha", "short_name": "Kosha", "start_url": "./", "scope": "./", "display": "standalone",
           "background_color": "#fff8ec", "theme_color": "#fff8ec",
           "icons": [{"src": "icon-192.png", "sizes": "192x192", "type": "image/png"},
                     {"src": "icon-512.png", "sizes": "512x512", "type": "image/png"}]},
          open(os.path.join(out, "manifest.webmanifest"), "w"), indent=1)
h = hashlib.sha1(html.encode()).hexdigest()[:10]
sw = """/* Kosha web %s — works offline after the first visit */
const C = "kosha-%s";
const CORE = ["./", "index.html", "manifest.webmanifest", "apple-touch-icon.png", "icon-192.png", "icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(C).then(c => c.addAll(CORE)).then(() => self.skipWaiting())); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== C).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener("fetch", e => {
  const u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== location.origin || u.pathname.startsWith("/__/")) return;
  if (e.request.mode === "navigate" || u.pathname.endsWith("/") || u.pathname.endsWith("index.html")) {
    e.respondWith(fetch(e.request).then(r => { const cp = r.clone(); caches.open(C).then(c => c.put("index.html", cp)); return r; }).catch(() => caches.match("index.html")));
    return;
  }
  e.respondWith(caches.match(e.request).then(m => m || fetch(e.request).then(r => { if (r.ok) { const cp = r.clone(); caches.open(C).then(c => c.put(e.request, cp)); } return r; })));
});
""" % (ver, h)
open(os.path.join(out, "sw.js"), "w").write(sw)
open(os.path.join(out, "version.txt"), "w").write(ver + "\n")
print("web build", ver, "->", out, "(%d KB)" % (len(html) // 1024))
