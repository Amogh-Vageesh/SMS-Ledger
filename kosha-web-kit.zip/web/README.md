# Kosha for iPhone (web edition)

Built automatically from `app/index.html` by `.github/workflows/deploy-web.yml`
and published to Firebase Hosting in the project `sms-ledger-family`:

  https://sms-ledger-family.web.app   (also https://sms-ledger-family.firebaseapp.com)

Needs the repository secret `FIREBASE_SERVICE_ACCOUNT` (the service-account JSON
from Firebase → Project settings → Service accounts → Generate new private key).

- `mkweb.py`  – turns the Android app's index.html into the web edition
- `src/bridge.js` – web stand-in for the Android bridge (Google sign-in, family
  sharing in the same Firestore layout as Android, storage in IndexedDB, files, rates)
- `src/post.js` – iPhone touches: one-tap Paste SMS, Shortcut setup guide, backups
- `src/firebase/` – Firebase JS SDK 10.14.1 (compat), bundled so the app also opens offline
