/* Kosha web edition (iPhone / any browser) — stands in for the Android app's native bridge.
   Same Firebase project and the same Firestore layout as the Android app, so family sharing
   works between Android and iPhone. Ledger data lives in this browser's IndexedDB. */
(function(){
  "use strict";
  var CFG = {
    apiKey: "AIzaSyDqqdfRtiH_EGCymKWayIW8C2-KifqXN0Q",
    authDomain: "sms-ledger-family.firebaseapp.com",
    projectId: "sms-ledger-family",
    storageBucket: "sms-ledger-family.firebasestorage.app",
    messagingSenderId: "255114822657",
    appId: "1:255114822657:web:f3654c9f10263fae202c00"
  };
  window.KOSHA_WEB = true;
  var CHUNK = 450000;

  /* ---------- small helpers ---------- */
  function cb(name, arg){ try{ if(typeof window[name] === "function") window[name](arg); }catch(e){ try{ console.warn(name, e); }catch(_){} } }
  function J(o){ return JSON.stringify(o); }
  function uuid(){ try{ return crypto.randomUUID(); }catch(e){ return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c){ var r = Math.random()*16|0; return (c === "x" ? r : (r&3|8)).toString(16); }); } }
  function code8(){ return uuid().replace(/-/g, "").slice(0, 8).toUpperCase(); }
  function now(){ return Date.now(); }
  function errMsg(e, d){ var m = (e && (e.message || e.code)) || d || "Something went wrong"; return String(m).replace(/^Firebase:\s*/,"").replace(/\s*\(auth\/[^)]+\)\.?$/,""); }
  function lsGet(k, d){ try{ var v = localStorage.getItem(k); return v == null ? d : v; }catch(e){ return d; } }
  function lsSet(k, v){ try{ localStorage.setItem(k, v); }catch(e){} }

  /* ---------- IndexedDB store for the ledger ---------- */
  var IDB = { db: null };
  IDB.open = function(){
    return new Promise(function(res){
      try{
        var rq = indexedDB.open("kosha", 1);
        rq.onupgradeneeded = function(){ var d = rq.result; if(!d.objectStoreNames.contains("kv")) d.createObjectStore("kv"); };
        rq.onsuccess = function(){ IDB.db = rq.result; res(IDB.db); };
        rq.onerror = function(){ res(null); };
      }catch(e){ res(null); }
    });
  };
  IDB.get = function(k){
    return new Promise(function(res){
      if(!IDB.db) return res(null);
      try{ var rq = IDB.db.transaction("kv", "readonly").objectStore("kv").get(k); rq.onsuccess = function(){ res(rq.result == null ? null : rq.result); }; rq.onerror = function(){ res(null); }; }catch(e){ res(null); }
    });
  };
  IDB.put = function(k, v){
    return new Promise(function(res){
      if(!IDB.db) return res(false);
      try{ var tx = IDB.db.transaction("kv", "readwrite"); tx.objectStore("kv").put(v, k); tx.oncomplete = function(){ res(true); }; tx.onerror = function(){ res(false); }; }catch(e){ res(false); }
    });
  };
  IDB.del = function(k){
    return new Promise(function(res){
      if(!IDB.db) return res(false);
      try{ var tx = IDB.db.transaction("kv", "readwrite"); tx.objectStore("kv").delete(k); tx.oncomplete = function(){ res(true); }; tx.onerror = function(){ res(false); }; }catch(e){ res(false); }
    });
  };
  IDB.keys = function(){
    return new Promise(function(res){
      if(!IDB.db) return res([]);
      try{ var rq = IDB.db.transaction("kv", "readonly").objectStore("kv").getAllKeys(); rq.onsuccess = function(){ res(rq.result || []); }; rq.onerror = function(){ res([]); }; }catch(e){ res([]); }
    });
  };
  window.__koshaIDB = IDB;

  /* ---------- Firebase ---------- */
  var fb = null, auth = null, fs = null;
  try{ fb = firebase.initializeApp(CFG); auth = firebase.auth(); fs = firebase.firestore(); }catch(e){ try{ console.warn("firebase init", e); }catch(_){} }
  var cachedUser = null; try{ cachedUser = JSON.parse(lsGet("kosha.webUser", "null")); }catch(e){}
  function userJson(u){ return u ? { uid: u.uid, name: u.displayName || "", email: u.email || "", photo: u.photoURL || "" } : null; }
  var authKnown = false, authWait = [];
  function whenAuth(){ return authKnown ? Promise.resolve() : new Promise(function(r){ authWait.push(r); }); }
  function requireUser(){ var u = auth && auth.currentUser; if(!u) throw new Error("Sign in with Google first."); return u; }
  if(auth){
    try{ auth.setPersistence(firebase.auth.Auth.Persistence.LOCAL); }catch(e){}
    auth.onAuthStateChanged(function(u){
      cachedUser = userJson(u); lsSet("kosha.webUser", J(cachedUser));
      authKnown = true; authWait.splice(0).forEach(function(f){ f(); });
      try{ var H = window.__koshaHooks; if(H){ H.setCloudUser(cachedUser); H.refreshCloud(); } }catch(e){}
      if(u && pendingListen) startListen(pendingListen);
    });
    /* coming back from a redirect sign-in */
    auth.getRedirectResult().then(function(r){
      if(r && r.user){ var o = userJson(r.user); o.ok = true; setTimeout(function(){ cb("cloudSignInResult", J(o)); }, 600); }
    }).catch(function(e){ if(lsGet("kosha.redirecting","") === "1"){ setTimeout(function(){ cb("cloudSignInResult", J({ ok:false, cancelled:false, error: errMsg(e, "Couldn't sign in") })); }, 600); } })
      .then(function(){ lsSet("kosha.redirecting", ""); });
  }

  /* ---------- Firestore helpers matching the Android layout ---------- */
  function fsValue(v){
    if(v === null || v === undefined) return undefined;
    if(typeof v === "number" || typeof v === "boolean" || typeof v === "string") return v;
    if(Array.isArray(v)) return v.filter(function(x){ return x !== null && x !== undefined; }).map(function(x){ return (typeof x === "object") ? J(x) : String(x); });
    return J(v);
  }
  function safeId(id){ return String(id).replace(/\//g, "_").slice(0, 1400) || uuid(); }
  function commitAll(ops){
    /* ops: [{type:"set"|"delete", ref, data, merge}] in batches of 400 */
    var p = Promise.resolve();
    for(var i = 0; i < ops.length; i += 400){
      (function(slice){
        p = p.then(function(){
          var b = fs.batch();
          slice.forEach(function(o){ if(o.type === "delete") b.delete(o.ref); else b.set(o.ref, o.data, o.merge ? { merge: true } : undefined); });
          return b.commit();
        });
      })(ops.slice(i, i + 400));
    }
    return p;
  }
  function replaceArray(col, arr, uid, t){
    var keep = {}, ops = [];
    (arr || []).forEach(function(item){
      if(!item || typeof item !== "object") return;
      var id = item.id != null && String(item.id).trim() ? String(item.id) : uuid();
      var data = { ownerUid: uid, updatedAt: t };
      Object.keys(item).forEach(function(k){ var v = fsValue(item[k]); if(v !== undefined) data[k] = v; });
      data.ownerUid = uid; data.updatedAt = t;
      var did = safeId(id); keep[did] = true;
      ops.push({ type: "set", ref: col.doc(did), data: data, merge: true });
    });
    return commitAll(ops).then(function(){ return col.where("ownerUid", "==", uid).get(); }).then(function(snap){
      var dels = []; snap.forEach(function(d){ if(!keep[d.id]) dels.push({ type: "delete", ref: d.ref }); });
      return commitAll(dels);
    });
  }
  function clearOwned(col, uid){
    return col.where("ownerUid", "==", uid).get().then(function(snap){ var dels = []; snap.forEach(function(d){ dels.push({ type: "delete", ref: d.ref }); }); return commitAll(dels); });
  }
  function replaceCompleteShares(col, shares, uid, t){
    return clearOwned(col, uid).then(function(){
      var ops = [];
      (shares || []).forEach(function(s){
        if(!s) return; var mu = String(s.uid || "").trim(), raw = String(s.raw || ""); if(!mu || !raw) return;
        var n = Math.max(1, Math.ceil(raw.length / CHUNK));
        for(var i = 0; i < n; i++) ops.push({ type: "set", ref: col.doc(uid + "_" + mu + "_" + i), merge: true, data: { ownerUid: uid, updatedAt: t, shareWith: "some", audienceUids: [mu], memberUid: mu, chunkIndex: i, chunkCount: n, dataChunk: raw.slice(i*CHUNK, (i+1)*CHUNK) } });
      });
      return commitSmall(ops);
    });
  }
  function replaceCompleteData(col, raw, shareWith, audience, uid, t){
    return clearOwned(col, uid).then(function(){
      raw = String(raw || ""); if(!raw) return;
      var list = (audience || []).map(String).filter(Boolean), n = Math.max(1, Math.ceil(raw.length / CHUNK)), ops = [];
      for(var i = 0; i < n; i++) ops.push({ type: "set", ref: col.doc(uid + "_" + i), merge: true, data: { ownerUid: uid, updatedAt: t, shareWith: shareWith || "all", audienceUids: list, chunkIndex: i, chunkCount: n, dataChunk: raw.slice(i*CHUNK, (i+1)*CHUNK) } });
      return commitSmall(ops);
    });
  }
  /* chunk documents are large (≈450 KB): write them one at a time, not in a batch (10 MB batch limit) */
  function commitSmall(ops){ var p = Promise.resolve(); ops.forEach(function(o){ p = p.then(function(){ return o.ref.set(o.data, { merge: true }); }); }); return p; }

  var publishing = false, publishNext = null;
  function doPublish(familyId, payload){
    var u = requireUser(), uid = u.uid, t = now();
    var fam = fs.collection("families").doc(familyId);
    return fam.collection("members").doc(uid).set({ uid: uid, name: u.displayName || "Member", email: u.email || "", updatedAt: t }, { merge: true })
      .then(function(){ return replaceArray(fam.collection("events"), payload.events, uid, t); })
      .then(function(){ return replaceArray(fam.collection("calendar"), payload.calendar, uid, t); })
      .then(function(){ return replaceArray(fam.collection("shopping"), payload.shopping, uid, t); })
      .then(function(){ return replaceArray(fam.collection("transactions"), payload.transactions, uid, t); })
      .then(function(){ return replaceArray(fam.collection("assetRequests"), payload.assetRequests, uid, t); })
      .then(function(){
        if(Array.isArray(payload.completeShares)) return replaceCompleteShares(fam.collection("completeData"), payload.completeShares, uid, t);
        return replaceCompleteData(fam.collection("completeData"), payload.completeData || "", payload.completeShareWith || "all", payload.completeAudienceUids || [], uid, t);
      });
  }
  function runPublish(familyId, payloadStr){
    if(publishing){ publishNext = [familyId, payloadStr]; return; }
    publishing = true;
    var payload; try{ payload = JSON.parse(payloadStr || "{}"); }catch(e){ payload = {}; }
    whenAuth().then(function(){ return doPublish(familyId, payload); })
      .then(function(){ cb("familyCloudPublishResult", J({ ok: true })); })
      .catch(function(e){ cb("familyCloudPublishResult", J({ ok: false, error: errMsg(e, "Could not sync family data") })); })
      .then(function(){ publishing = false; if(publishNext){ var n = publishNext; publishNext = null; runPublish(n[0], n[1]); } });
  }

  var listeners = [], pendingListen = null, listenTimer = null;
  function stopListen(){ listeners.forEach(function(f){ try{ f(); }catch(e){} }); listeners = []; }
  function startListen(familyId){
    if(!fs) return; if(!(auth && auth.currentUser)){ pendingListen = familyId; return; }
    pendingListen = null; stopListen();
    var uid = auth.currentUser.uid, fam = fs.collection("families").doc(familyId), maps = {};
    var emit = function(){ clearTimeout(listenTimer); listenTimer = setTimeout(function(){ var o = {}; Object.keys(maps).forEach(function(k){ o[k] = Object.keys(maps[k]).map(function(id){ return maps[k][id]; }); }); cb("familyCloudArrived", J(o)); }, 250); };
    ["events","calendar","shopping","transactions","assetRequests","completeData","members"].forEach(function(name){
      var col = fam.collection(name), qs = name === "members" ? [col] : [col.where("shareWith", "==", "all"), col.where("audienceUids", "array-contains", uid)];
      maps[name] = maps[name] || {};
      qs.forEach(function(q){
        listeners.push(q.onSnapshot(function(snap){
          snap.docChanges().forEach(function(ch){ if(ch.type === "removed") delete maps[name][ch.doc.id]; else maps[name][ch.doc.id] = ch.doc.data(); });
          emit();
        }, function(err){ cb("familyCloudError", errMsg(err, "Family sync error")); }));
      });
    });
  }

  /* ---------- currency rates (same sources as Android) ---------- */
  function fetchRate(cur, date){
    var c = String(cur || "").toUpperCase(), d = String(date || "latest").slice(0, 10) || "latest";
    var tries = [
      function(){ return fetch("https://api.frankfurter.dev/v1/" + d + "?base=" + c + "&symbols=INR").then(function(r){ return r.json(); }).then(function(j){ return j && j.rates && j.rates.INR; }); },
      function(){ return fetch("https://api.frankfurter.app/" + d + "?from=" + c + "&to=INR").then(function(r){ return r.json(); }).then(function(j){ return j && j.rates && j.rates.INR; }); },
      function(){ return fetch("https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@" + d + "/v1/currencies/" + c.toLowerCase() + ".json").then(function(r){ return r.json(); }).then(function(j){ return j && j[c.toLowerCase()] && j[c.toLowerCase()].inr; }); }
    ];
    var i = 0;
    var next = function(){ if(i >= tries.length) return Promise.resolve(0); return tries[i++]().then(function(v){ return Number(v) > 0 ? Number(v) : next(); }, next); };
    return next();
  }

  /* ---------- files: share sheet on iPhone, download elsewhere ---------- */
  var MIME = { pdf:"application/pdf", doc:"application/msword", docx:"application/vnd.openxmlformats-officedocument.wordprocessingml.document", html:"text/html", htm:"text/html", csv:"text/csv", txt:"text/plain", json:"application/json", jpg:"image/jpeg", jpeg:"image/jpeg", png:"image/png", xls:"application/vnd.ms-excel", xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" };
  function saveFile(name, data){
    name = String(name || "kosha-file"); data = String(data == null ? "" : data);
    var ext = (name.split(".").pop() || "").toLowerCase(), type = MIME[ext] || "application/octet-stream", blob;
    if(data.indexOf("base64:") === 0){ var bin = atob(data.slice(7)), u8 = new Uint8Array(bin.length); for(var i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); blob = new Blob([u8], { type: type }); }
    else blob = new Blob([data], { type: type + (/^text|json/.test(type) ? ";charset=utf-8" : "") });
    try{
      var file = new File([blob], name, { type: type });
      if(navigator.canShare && navigator.share && navigator.canShare({ files: [file] })){
        navigator.share({ files: [file], title: name }).catch(function(e){ if(e && e.name !== "AbortError") download(blob, name); });
        return;
      }
    }catch(e){}
    download(blob, name);
  }
  function download(blob, name){ var url = URL.createObjectURL(blob), a = document.createElement("a"); a.href = url; a.download = name; a.rel = "noopener"; document.body.appendChild(a); a.click(); setTimeout(function(){ URL.revokeObjectURL(url); a.remove(); }, 4000); }

  /* ---------- the bridge ---------- */
  var preState = "";
  var saveQ = Promise.resolve();
  window.Android = {
    __web: true,
    /* storage */
    loadState: function(){ return preState || ""; },
    saveState: function(json){ var s = String(json || ""); preState = s; saveQ = saveQ.then(function(){ return IDB.put("ledger", s); }).then(function(ok){ if(!ok){ try{ localStorage.setItem("smsLedger.webFallback", s); }catch(e){} } }); },
    /* sign-in */
    getCurrentUser: function(){ var u = auth && auth.currentUser ? userJson(auth.currentUser) : cachedUser; return u ? J(u) : "null"; },
    signIn: function(){
      if(!auth){ cb("cloudSignInResult", J({ ok:false, error:"Sign-in isn't available — check your internet connection." })); return; }
      var p = new firebase.auth.GoogleAuthProvider(); p.setCustomParameters({ prompt: "select_account" });
      auth.signInWithPopup(p).then(function(r){ var o = userJson(r.user); o.ok = true; cb("cloudSignInResult", J(o)); })
        .catch(function(e){
          var c = (e && e.code) || "";
          if(/popup-closed-by-user|cancelled-popup-request|user-cancelled/.test(c)){ cb("cloudSignInResult", J({ ok:false, cancelled:true })); return; }
          if(/popup-blocked|operation-not-supported|web-storage-unsupported/.test(c)){ lsSet("kosha.redirecting", "1"); auth.signInWithRedirect(p).catch(function(e2){ cb("cloudSignInResult", J({ ok:false, cancelled:false, error: errMsg(e2, "Couldn't sign in") })); }); return; }
          cb("cloudSignInResult", J({ ok:false, cancelled:false, error: errMsg(e, "Couldn't sign in") }));
        });
    },
    signOutCloud: function(){ stopListen(); (auth ? auth.signOut() : Promise.resolve()).then(function(){ cb("cloudSignInResult", J({ ok:false, signedOut:true })); }, function(e){ cb("cloudSignInResult", J({ ok:false, error: errMsg(e, "Couldn't sign out") })); }); },
    setOnboardingComplete: function(){ lsSet("kosha.onboardingComplete", "1"); },
    /* family cloud — same Firestore layout as the Android app */
    createFamily: function(name){
      whenAuth().then(function(){
        var u = requireUser(), id = uuid(), code = code8(), t = now(), nm = String(name || "").trim() || "My Family";
        return fs.collection("families").doc(id).set({ ownerUid: u.uid, createdAt: t, inviteCode: code, name: nm })
          .then(function(){ return fs.collection("familyInvites").doc(code).set({ familyId: id, createdAt: t }); })
          .then(function(){ return fs.collection("families").doc(id).collection("members").doc(u.uid).set({ uid: u.uid, name: u.displayName || "Member", email: u.email || "", role: "owner", joinedAt: t }); })
          .then(function(){ cb("familyCloudResult", J({ ok:true, familyId: id, inviteCode: code, name: nm })); });
      }).catch(function(e){ cb("familyCloudResult", J({ ok:false, error: errMsg(e, "Couldn't create the family") })); });
    },
    joinFamily: function(codeRaw, name){
      whenAuth().then(function(){
        var u = requireUser(), code = String(codeRaw || "").trim().toUpperCase();
        if(code.length < 6) throw new Error("Enter the family code.");
        return fs.collection("familyInvites").doc(code).get().then(function(s){
          if(!s.exists) throw new Error("Family code not found.");
          var fid = s.get("familyId"); if(!fid) throw new Error("Invalid family code.");
          var nm = String(name || "").trim() || u.displayName || "Member";
          return fs.collection("families").doc(fid).collection("members").doc(u.uid).set({ uid: u.uid, name: nm, email: u.email || "", role: "member", joinedAt: now() })
            .then(function(){ cb("familyCloudResult", J({ ok:true, familyId: fid, inviteCode: code })); });
        });
      }).catch(function(e){ cb("familyCloudResult", J({ ok:false, error: errMsg(e, "Couldn't join the family") })); });
    },
    publishFamily: function(familyId, payload){ if(!familyId || !fs) return; runPublish(String(familyId), payload); },
    listenFamily: function(familyId){ if(!familyId) return; whenAuth().then(function(){ startListen(String(familyId)); }); },
    getFamilyInfo: function(familyId){
      whenAuth().then(function(){
        requireUser(); var fam = fs.collection("families").doc(String(familyId));
        return Promise.all([fam.get(), fam.collection("members").get()]).then(function(r){
          var d = r[0].exists ? r[0].data() : {}, members = []; r[1].forEach(function(m){ members.push(m.data()); });
          cb("familyInfoResult", J({ ok:true, familyId: String(familyId), inviteCode: d.inviteCode || "", name: d.name || "", members: members }));
        });
      }).catch(function(e){ cb("familyInfoResult", J({ ok:false, error: errMsg(e, "Couldn't load family") })); });
    },
    /* backup: snapshots kept on this iPhone, plus "Download a backup" in Settings */
    getBackupSchedule: function(){ return lsGet("kosha.backupSchedule", "weekly"); },
    setBackupSchedule: function(f){ lsSet("kosha.backupSchedule", /^(off|daily|weekly)$/.test(f) ? f : "off"); },
    backupNow: function(){ if(!preState) return false; webBackup(); return true; },
    /* exchange rates */
    getRate: function(id, cur, date){ fetchRate(cur, date).then(function(v){ cb2("rateResult", id, v); }); },
    /* files */
    saveFile: saveFile,
    /* SMS: an iPhone can't give apps its messages — Paste SMS / the Shortcut bring them in */
    hasSmsAccess: function(){ return true; },
    hasPhoneStateAccess: function(){ return true; },
    isSmsDataUnlocked: function(){ return true; },
    requestSms: function(){ setTimeout(function(){ cb("smsPermissionGranted"); }, 0); },
    importRange: function(){ setTimeout(function(){ try{ if(!window.__kwHelpSession && typeof window.koshaWebSmsHelp === "function") window.koshaWebSmsHelp(true); }catch(e){} try{ window.importFinished && window.importFinished(0, 0); }catch(e){} }, 50); },
    setSmsConsentConfirmed: function(){}, setInitialImportDone: function(){}, resetSmsOnboarding: function(){},
    setLanguage: function(l){ lsSet("kosha.lang", String(l || "")); }, languageChosen: function(){},
    setTheme: function(t){ try{ var dark = t === "dark" || (t !== "light" && window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches); document.documentElement.dataset.theme = dark ? "dark" : "light"; }catch(e){} },
    isAppLockEnabled: function(){ return false; }, setAppLockEnabled: function(){},
    setReminders: function(json){ lsSet("kosha.reminders", String(json || "[]")); },
    getSigningFingerprints: function(){ return ""; }
  };
  function cb2(name, a, b){ try{ if(typeof window[name] === "function") window[name](a, b); }catch(e){} }

  function webBackup(){
    var t = new Date(), key = "backup-" + t.toISOString().replace(/[:.]/g, "-");
    IDB.put(key, preState).then(function(){ lsSet("kosha.lastBackup", String(t.getTime())); return IDB.keys(); }).then(function(keys){
      keys.filter(function(k){ return /^backup-/.test(k); }).sort().reverse().slice(5).forEach(function(k){ IDB.del(k); });
    });
  }
  window.koshaWebBackups = function(){ return IDB.keys().then(function(keys){ return keys.filter(function(k){ return /^backup-/.test(k); }).sort().reverse(); }); };
  window.koshaWebRestore = function(key){ return IDB.get(key).then(function(raw){ if(!raw) return false; return IDB.put("ledger", raw).then(function(){ location.reload(); return true; }); }); };


  /* ---------- automatic SMS: a private inbox the iPhone Shortcut posts to ---------- */
  var INBOX = {};
  function randKey(n){ var a = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789", out = "", b = new Uint8Array(n); try{ crypto.getRandomValues(b); }catch(e){ for(var i = 0; i < n; i++) b[i] = Math.random()*256|0; } for(var j = 0; j < n; j++) out += a[b[j] % a.length]; return out; }
  INBOX.key = function(){ return lsGet("kosha.smsKey", ""); };
  INBOX.url = function(k){ k = k || INBOX.key(); return k ? "https://firestore.googleapis.com/v1/projects/" + CFG.projectId + "/databases/(default)/documents/smsInbox/" + k + "/items?key=" + CFG.apiKey : ""; };
  INBOX.signedIn = function(){ return !!(auth && auth.currentUser); };
  /* find this account's inbox (after reinstalling Kosha) */
  INBOX.recover = function(){
    if(INBOX.key() || !fs) return Promise.resolve(INBOX.key());
    return whenAuth().then(function(){ var u = auth && auth.currentUser; if(!u) return ""; return fs.collection("smsInbox").where("uid", "==", u.uid).limit(1).get().then(function(q){ var k = ""; q.forEach(function(d){ k = d.id; }); if(k) lsSet("kosha.smsKey", k); return k; }); }).catch(function(){ return ""; });
  };
  INBOX.enable = function(){
    return whenAuth().then(function(){ var u = requireUser(); return INBOX.recover().then(function(k){ if(k) return k; k = randKey(32);
      return fs.collection("smsInbox").doc(k).set({ uid: u.uid, createdAt: now() }).then(function(){ lsSet("kosha.smsKey", k); return k; }); }); });
  };
  INBOX.disable = function(){
    var k = INBOX.key(); if(!k) return Promise.resolve();
    var ref = fs.collection("smsInbox").doc(k);
    return ref.collection("items").get().then(function(q){ var ops = []; q.forEach(function(d){ ops.push({ type: "delete", ref: d.ref }); }); return commitAll(ops); })
      .then(function(){ return ref.delete(); }).catch(function(){}).then(function(){ lsSet("kosha.smsKey", ""); });
  };
  /* the same request the Shortcut sends — used by "Send a test" */
  INBOX.test = function(){
    var url = INBOX.url(); if(!url) return Promise.reject(new Error("Turn on automatic SMS first."));
    return fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: J({ fields: { text: { stringValue: "KOSHA-TEST " + new Date().toLocaleTimeString() } } }) })
      .then(function(r){ if(!r.ok) return r.text().then(function(t){ throw new Error("HTTP " + r.status + " " + t.slice(0, 160)); }); return true; });
  };
  var polling = false;
  INBOX.poll = function(){
    var k = INBOX.key(); if(!k || !fs || polling || !(auth && auth.currentUser)) return Promise.resolve(0);
    polling = true;
    var col = fs.collection("smsInbox").doc(k).collection("items");
    return col.get().then(function(q){
      var list = [], dels = [], tests = 0;
      q.forEach(function(d){ var x = d.data() || {}, txt = String(x.text || "").trim(); dels.push({ type: "delete", ref: d.ref });
        if(!txt) return; if(/^KOSHA-TEST\b/.test(txt)){ tests++; return; }
        var at = Number(x.at) || (x.at ? Date.parse(x.at) : 0) || Date.now();
        list.push({ body: txt, date: at, address: String(x.from || "") }); });
      list.sort(function(a, b){ return a.date - b.date; });
      var added = 0;
      if(list.length){ try{ added = (typeof window.ingestSms === "function") ? window.ingestSms(list, false) : 0; }catch(e){ try{ console.warn("ingest", e); }catch(_){} } }
      return commitAll(dels).then(function(){ if(tests) cb("koshaInboxTest", tests); return { messages: list.length, added: added }; });
    }).catch(function(e){ return { error: errMsg(e, "") }; }).then(function(r){ polling = false; return r; });
  };
  window.koshaSmsInbox = INBOX;
  function pollSoon(){ setTimeout(function(){ INBOX.poll(); }, 1200); }
  document.addEventListener("visibilitychange", function(){ if(document.visibilityState === "visible") pollSoon(); });
  window.addEventListener("focus", pollSoon);
  setInterval(function(){ if(document.visibilityState === "visible") INBOX.poll(); }, 60000);

  /* ---------- boot: load the ledger from IndexedDB, then start the app ---------- */
  window.__koshaBoot = function(start){
    IDB.open().then(function(){ return IDB.get("ledger"); }).then(function(raw){
      if(!raw){ try{ raw = localStorage.getItem("smsLedger.webFallback") || ""; }catch(e){} }
      preState = raw || "";
      /* automatic backup */
      var sch = lsGet("kosha.backupSchedule", "weekly"), last = +lsGet("kosha.lastBackup", "0") || 0, gap = sch === "daily" ? 864e5 : sch === "weekly" ? 7*864e5 : 0;
      if(preState && gap && Date.now() - last > gap) webBackup();
      try{ if(navigator.storage && navigator.storage.persist) navigator.storage.persist(); }catch(e){}
      start();
      whenAuth().then(function(){ return INBOX.recover(); }).then(function(){ setTimeout(function(){ INBOX.poll(); }, 2500); });
    });
  };
})();
