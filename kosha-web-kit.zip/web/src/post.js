/* Kosha web edition — iPhone touches that run after the app has started */
(function(){
  "use strict";
  /* let the bridge update the signed-in user inside the app */
  window.__koshaHooks = { setCloudUser: function(u){ try{ cloudUser = u; }catch(e){} }, refreshCloud: function(){ try{ refreshCloudBlock(); }catch(e){} try{ render(); }catch(e){} } };
  try{ if(window.Android && window.Android.getCurrentUser){ var cu = JSON.parse(window.Android.getCurrentUser()); if(cu && !cloudUser) cloudUser = cu; } }catch(e){}
  var isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  var standalone = !!(window.navigator.standalone || (window.matchMedia && matchMedia("(display-mode: standalone)").matches));
  var T = function(s){ try{ return (typeof window.V2 !== "undefined" && V2.tr) ? V2.tr(s) : s; }catch(e){ return s; } };
  function esc(s){ return String(s == null ? "" : s).replace(/[&<>"]/g, function(c){ return { "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[c]; }); }
  function tst(m){ try{ toast(m); }catch(e){} }

  /* SMS onboarding: no SMS permission on iPhone — mark it done and show how SMS get in */
  try{
    showSmsConsent = function(){
      try{ state.smsPermissionConfirmed = true; state.smsDataReady = true; state.smsConsentUiVersion = 2; state.onboardingComplete = true; state.initialImportDone = true; persist([], true); }catch(e){}
      try{ render(); }catch(e){}
      if(!localStorageGet("kosha.smsHelpShown")){ localStorageSet("kosha.smsHelpShown", "1"); setTimeout(function(){ window.koshaWebSmsHelp(false); }, 300); }
    };
  }catch(e){}
  /* nothing to scan on iPhone: finish the "import" quietly */
  try{ var _imf = window.importFinished; window.importFinished = function(a, n){ if(!a && !n){ try{ state.smsDataReady = true; state.smsConsentUiVersion = 2; saveLocal(); render(); }catch(e){} return; } return _imf ? _imf.apply(this, arguments) : undefined; }; }catch(e){}
  function localStorageGet(k){ try{ return localStorage.getItem(k); }catch(e){ return null; } }
  function localStorageSet(k, v){ try{ localStorage.setItem(k, v); }catch(e){} }

  /* one tap: read the copied SMS and show what Kosha found */
  window.koshaPasteSms = function(){
    var open = function(text){
      try{ view = "add"; window.scrollTo(0, 0); render(); }catch(e){}
      setTimeout(function(){
        var ta = document.getElementById("smsIn"); if(!ta) return;
        if(text){ ta.value = text; var b = document.getElementById("parseBtn"); if(b) b.click(); }
        else { ta.focus(); tst(T("Long-press the box and tap Paste.")); }
      }, 80);
    };
    try{
      if(navigator.clipboard && navigator.clipboard.readText){
        navigator.clipboard.readText().then(function(t){ open(String(t || "").trim()); }, function(){ open(""); });
        return;
      }
    }catch(e){}
    open("");
  };

  /* how SMS get into Kosha on an iPhone */
  window.koshaWebSmsHelp = function(fromImport){
    if(document.getElementById("kwSmsHelp")) return; window.__kwHelpSession = true;
    var sc = document.createElement("div"); sc.className = "scrim"; sc.id = "kwSmsHelp";
    sc.innerHTML = '<div class="sheet kw-sheet"><h2>📩 ' + esc(T("Bank SMS on iPhone")) + '</h2>' +
      '<p class="help">' + esc(T("iPhones don't let any app read your messages, so Kosha gets them in one of two ways:")) + '</p>' +
      '<div class="kw-step"><b>1. ' + esc(T("Copy & paste (any time)")) + '</b><p>' + esc(T("In Messages, long-press a bank SMS → Copy. Open Kosha and tap 📋 Paste SMS. You can copy several messages at once — duplicates are skipped.")) + '</p></div>' +
      '<div class="kw-step"><b>2. ' + esc(T("Automatic (recommended)")) + '</b><p>' + esc(T("A one-time Shortcuts automation sends each new bank SMS to your Kosha account. Open Kosha and the entries are already added. Set it up in Settings → iPhone → Automatic SMS.")) + '</p></div>' +
      '<div class="row" style="gap:8px;margin-top:12px"><button type="button" class="btn primary" data-kw="paste">📋 ' + esc(T("Paste SMS now")) + '</button><button type="button" class="btn" data-kw="auto">⚡ ' + esc(T("Automatic SMS")) + '</button><button type="button" class="btn" data-kw="x">' + esc(T("Close")) + '</button></div></div>';
    document.body.appendChild(sc);
    sc.addEventListener("click", function(e){
      var b = e.target.closest("[data-kw]"); if(e.target === sc || (b && b.dataset.kw === "x")){ sc.remove(); return; }
      if(!b) return; sc.remove();
      if(b.dataset.kw === "paste") window.koshaPasteSms();
      if(b.dataset.kw === "guide") window.koshaShortcutGuide();
      if(b.dataset.kw === "auto") window.koshaAutoSms();
    });
  };


  /* ⚡ Automatic SMS: the Shortcut posts each bank SMS to this account's private inbox; Kosha adds them when opened */
  window.koshaInboxTest = function(){ tst(T("✅ Automatic SMS is working — test message received.")); };
  window.koshaAutoSms = function(){
    var IB = window.koshaSmsInbox; if(!IB) return;
    var old = document.getElementById("kwAuto"); if(old) old.remove();
    var sc = document.createElement("div"); sc.className = "scrim"; sc.id = "kwAuto";
    var key = IB.key(), url = IB.url(), signed = IB.signedIn();
    var steps = [
      ["Open Shortcuts → Automation", "Tap + (New Automation) and choose Message."],
      ["Message Contains: debited", "Leave Sender empty. Choose Run Immediately, then Next → New Blank Automation."],
      ["Add “Get Contents of URL”", "Search for it in Add Action. Tap the URL field and paste your link (Copy link above)."],
      ["Set it to send the SMS", "Tap the ⌄ arrow on the action: Method → POST, Request Body → JSON. Tap Add new field → Dictionary, key: fields. Open it, Add new field → Dictionary, key: text. Open that, Add new field → Text, key: stringValue, and for its value tap Select Variable → Shortcut Input."],
      ["Done — then two more", "Tap Done. Long-press the automation → Duplicate, and change the word to credited. Do it once more for spent."],
      ["Check it", "Tap Send a test below, then reopen Kosha — you'll see “Automatic SMS is working”."]
    ];
    var body;
    if(!signed) body = '<p class="help">' + esc(T("Sign in with Google first — your SMS inbox is tied to your account so only you can read it.")) + '</p><div class="row" style="gap:8px;margin-top:10px"><button type="button" class="btn primary" data-au="signin">' + esc(T("Sign in with Google")) + '</button><button type="button" class="btn" data-au="x">' + esc(T("Close")) + '</button></div>';
    else if(!key) body = '<p class="help">' + esc(T("Each bank SMS goes straight from your iPhone into a private inbox in your Kosha account. When you open Kosha, the entries are added for you — no copy or paste.")) + '</p><div class="row" style="gap:8px;margin-top:10px"><button type="button" class="btn primary" data-au="on">' + esc(T("Turn on automatic SMS")) + '</button><button type="button" class="btn" data-au="x">' + esc(T("Close")) + '</button></div>';
    else body = '<p class="help">' + esc(T("Your private link (keep it to yourself — anyone with it could send SMS into your Kosha):")) + '</p>' +
      '<div class="kw-url" id="kwUrl">' + esc(url) + '</div><div class="row" style="gap:8px;margin:8px 0 4px;flex-wrap:wrap"><button type="button" class="btn primary" data-au="copy">' + esc(T("Copy link")) + '</button><button type="button" class="btn" data-au="test">' + esc(T("Send a test")) + '</button><button type="button" class="btn" data-au="check">' + esc(T("Check now")) + '</button></div>' +
      steps.map(function(x, i){ return '<div class="kw-step"><b>' + (i + 1) + '. ' + esc(T(x[0])) + '</b><p>' + esc(T(x[1])) + '</p></div>'; }).join("") +
      '<div class="row" style="gap:8px;margin-top:12px;flex-wrap:wrap"><button type="button" class="btn primary" data-au="x">' + esc(T("Done")) + '</button><button type="button" class="btn" data-au="off">' + esc(T("Turn off")) + '</button></div>';
    sc.innerHTML = '<div class="sheet kw-sheet"><h2>⚡ ' + esc(T("Automatic SMS")) + '</h2>' + body + '</div>';
    document.body.appendChild(sc);
    sc.addEventListener("click", function(e){
      var b = e.target.closest("[data-au]"); if(e.target === sc || (b && b.dataset.au === "x")){ sc.remove(); return; } if(!b) return;
      var a = b.dataset.au;
      if(a === "signin"){ sc.remove(); try{ window.Android.signIn(); }catch(err){} return; }
      if(a === "on"){ b.disabled = true; b.textContent = T("Turning on…"); IB.enable().then(function(){ window.koshaAutoSms(); }, function(err){ b.disabled = false; b.textContent = T("Turn on automatic SMS"); tst((err && err.message) || T("Couldn't turn it on")); }); return; }
      if(a === "copy"){ var u = IB.url(); try{ navigator.clipboard.writeText(u).then(function(){ tst(T("Link copied")); }, function(){ selectUrl(); }); }catch(err){ selectUrl(); } return; }
      if(a === "test"){ b.disabled = true; IB.test().then(function(){ b.disabled = false; return IB.poll(); }, function(err){ b.disabled = false; tst(T("Test failed: ") + ((err && err.message) || "")); }); return; }
      if(a === "check"){ IB.poll().then(function(r){ if(r && r.error) tst(r.error); else if(r && r.messages) tst(r.messages + " " + T("new SMS added")); else tst(T("No new SMS")); }); return; }
      if(a === "off"){ if(!b.dataset.armed){ b.dataset.armed = "1"; b.textContent = T("Tap again to turn off"); return; } IB.disable().then(function(){ sc.remove(); tst(T("Automatic SMS turned off")); }); return; }
    });
    function selectUrl(){ var el = document.getElementById("kwUrl"); if(!el) return; var r = document.createRange(); r.selectNodeContents(el); var s = window.getSelection(); s.removeAllRanges(); s.addRange(r); tst(T("Link selected — tap Copy")); }
  };

  window.koshaShortcutGuide = function(){
    if(document.getElementById("kwGuide")) return;
    var steps = [
      ["Open the Shortcuts app", "It comes with every iPhone. Tap Automation at the bottom, then + (or New Automation)."],
      ["Choose Message", "Set Message Contains to: debited. Leave Sender empty. Choose Run Immediately (turn off Notify When Run if you like), then tap Next."],
      ["Add the action", "Tap New Blank Automation → Add Action → search Copy to Clipboard and add it. Tap the blue Content and pick Shortcut Input → Message (its text)."],
      ["Save it", "Tap Done. Make two more the same way for credited and spent, so card spends and money received are caught too."],
      ["Use it", "When a bank SMS arrives, it's copied for you. Open Kosha and tap 📋 Paste SMS — Kosha reads it and shows the entry to add."],
      ["Several at once (optional)", "If you'd rather add them in one go: in the automation use Append to Note (note name: Kosha SMS) instead of Copy to Clipboard. Later open the note, Select All → Copy, then tap 📋 Paste SMS. Duplicates are skipped, so you can clear the note whenever you like."]
    ];
    var sc = document.createElement("div"); sc.className = "scrim"; sc.id = "kwGuide";
    sc.innerHTML = '<div class="sheet kw-sheet"><h2>⚡ ' + esc(T("iPhone SMS setup")) + '</h2><p class="help">' + esc(T("One-time setup, about 2 minutes. Needs iOS 17 or newer to run without asking each time.")) + '</p>' +
      steps.map(function(s, i){ return '<div class="kw-step"><b>' + (i + 1) + '. ' + esc(T(s[0])) + '</b><p>' + esc(T(s[1])) + '</p></div>'; }).join("") +
      '<div class="row" style="gap:8px;margin-top:12px"><button type="button" class="btn primary" data-kw="x">' + esc(T("Done")) + '</button></div></div>';
    document.body.appendChild(sc);
    sc.addEventListener("click", function(e){ if(e.target === sc || e.target.closest("[data-kw]")) sc.remove(); });
  };

  /* 📋 Paste SMS — always one tap away: a button on Home, and first in the + menu */
  function addHomeButton(){
    var home = document.getElementById("v-home"); if(!home || home.classList.contains("hidden")) return;
    if(document.getElementById("kwPasteHome")) return;
    var b = document.createElement("button"); b.type = "button"; b.id = "kwPasteHome"; b.className = "kw-paste"; b.innerHTML = '📋 <span>' + esc(T("Paste SMS")) + '</span>';
    b.onclick = function(e){ e.preventDefault(); window.koshaPasteSms(); };
    document.body.appendChild(b);
  }
  function syncHomeButton(){
    var b = document.getElementById("kwPasteHome"), home = document.getElementById("v-home");
    var show = !!(home && !home.classList.contains("hidden") && home.offsetParent !== null) && !Array.prototype.some.call(document.querySelectorAll(".scrim"), function(x){ return x.offsetParent !== null || getComputedStyle(x).position === "fixed" && getComputedStyle(x).display !== "none"; });
    if(show && !b) addHomeButton(); else if(b) b.style.display = show ? "" : "none";
  }
  setInterval(syncHomeButton, 500); setTimeout(syncHomeButton, 300);

  /* the + menu: put Paste SMS first, labelled for iPhone */
  try{
    var mo = new MutationObserver(function(){
      document.querySelectorAll(".scrim .sheet").forEach(function(sh){
        if(sh.dataset.kw) return; sh.dataset.kw = "1";
        var items = Array.prototype.slice.call(sh.querySelectorAll("button, .v2-item, [role=button]"));
        var it = items.find(function(x){ return /Scan SMS|Paste bank SMS|ಬ್ಯಾಂಕ್ SMS ಅಂಟಿಸಿ|SMS ಸ್ಕ್ಯಾನ್/.test(x.textContent || ""); });
        if(!it) return;
        /* on iPhone this item pastes the copied SMS straight away */
        try{ var lab = it.querySelector("b"), sub = it.querySelector("small");
          if(lab) lab.textContent = T("Paste SMS"); if(sub) sub.textContent = T("Read the bank SMS you copied"); }catch(e){}
        it.addEventListener("click", function(e){ e.preventDefault(); e.stopImmediatePropagation(); var sc = it.closest(".scrim"); if(sc) sc.remove(); window.koshaPasteSms(); }, true);
        if(it.parentNode && it.parentNode.firstElementChild !== it){ it.parentNode.insertBefore(it, it.parentNode.firstElementChild); }
      });
    });
    mo.observe(document.body, { childList: true });
  }catch(e){}

  /* Paste page: make the clipboard button do paste + read in one tap, and add the setup link */
  try{
    var pb = document.getElementById("pasteBtn");
    if(pb){ pb.textContent = "📋 " + T("Paste & read"); pb.classList.add("primary");
      pb.onclick = function(){ window.koshaPasteSms(); }; }
    var add = document.getElementById("v-add");
    if(add && !document.getElementById("kwGuideLink")){
      var p = document.createElement("p"); p.className = "help"; p.id = "kwGuideLink";
      p.innerHTML = '⚡ <a href="#" id="kwGuideA">' + esc(T("Set up automatic SMS on iPhone")) + '</a>';
      add.appendChild(p); document.getElementById("kwGuideA").onclick = function(e){ e.preventDefault(); window.koshaAutoSms(); };
    }
  }catch(e){}

  /* Settings: iPhone SMS setup + backups on this iPhone */
  function addSettings(){
    var s = document.getElementById("v-settings"); if(!s || document.getElementById("kwSettings")) return;
    var box = document.createElement("div"); box.className = "card"; box.id = "kwSettings"; box.style.marginTop = "10px";
    box.innerHTML = '<div class="card-h"><b>📱 ' + esc(T("iPhone")) + '</b></div>' +
      '<div class="row" style="flex-wrap:wrap;gap:8px"><button type="button" class="btn primary" id="kwSetAuto">⚡ ' + esc(T("Automatic SMS")) + '</button><button type="button" class="btn" id="kwSetGuide">📋 ' + esc(T("Copy & paste setup")) + '</button><button type="button" class="btn" id="kwSetBackups">🗂️ ' + esc(T("Backups on this iPhone")) + '</button></div>' +
      '<p class="help">' + esc(T("Your data is kept on this iPhone. Kosha also keeps the last 5 automatic backups here; download one now and then to keep a copy in Files or iCloud Drive.")) + '</p>';
    s.insertBefore(box, s.firstElementChild ? s.firstElementChild.nextSibling : null);
    document.getElementById("kwSetGuide").onclick = function(){ window.koshaShortcutGuide(); };
    document.getElementById("kwSetAuto").onclick = function(){ window.koshaAutoSms(); };
    document.getElementById("kwSetBackups").onclick = showBackups;
  }
  function showBackups(){
    window.koshaWebBackups().then(function(keys){
      var sc = document.createElement("div"); sc.className = "scrim";
      var nice = function(k){ var m = /^backup-(\d{4})-(\d\d)-(\d\d)T(\d\d)-(\d\d)/.exec(k); return m ? (m[3] + "/" + m[2] + "/" + m[1] + " " + m[4] + ":" + m[5]) : k; };
      sc.innerHTML = '<div class="sheet kw-sheet"><h2>🗂️ ' + esc(T("Backups on this iPhone")) + '</h2>' +
        (keys.length ? keys.map(function(k){ return '<div class="kw-bk"><span>' + esc(nice(k)) + '</span><span><button type="button" class="btn" data-dl="' + esc(k) + '">' + esc(T("Download")) + '</button> <button type="button" class="btn" data-rs="' + esc(k) + '">' + esc(T("Restore")) + '</button></span></div>'; }).join("") : '<p class="help">' + esc(T("No backups yet.")) + '</p>') +
        '<div class="row" style="gap:8px;margin-top:12px"><button type="button" class="btn primary" data-bk="now">' + esc(T("Back up now")) + '</button><button type="button" class="btn" data-bk="x">' + esc(T("Close")) + '</button></div></div>';
      document.body.appendChild(sc);
      sc.addEventListener("click", function(e){
        var t = e.target;
        if(t === sc || t.closest('[data-bk="x"]')){ sc.remove(); return; }
        if(t.closest('[data-bk="now"]')){ window.Android.backupNow(); sc.remove(); tst(T("Backed up on this iPhone.")); return; }
        var dl = t.closest("[data-dl]"); if(dl){ window.__koshaIDB.get(dl.dataset.dl).then(function(raw){ if(raw) window.Android.saveFile("kosha-" + dl.dataset.dl + ".json", raw); }); return; }
        var rs = t.closest("[data-rs]"); if(rs){ if(rs.dataset.armed){ window.koshaWebRestore(rs.dataset.rs); } else { rs.dataset.armed = "1"; rs.textContent = T("Tap again to restore"); } }
      });
    });
  }
  setTimeout(addSettings, 500); setInterval(addSettings, 2000);

  /* SMS passed in the link (…/#sms=…) */
  try{
    var m = /[#&?]sms=([^&]+)/.exec(location.hash + "&" + location.search);
    if(m){ var txt = decodeURIComponent(m[1].replace(/\+/g, " ")); history.replaceState(null, "", location.pathname);
      setTimeout(function(){ try{ view = "add"; window.scrollTo(0, 0); render(); }catch(e){} var ta = document.getElementById("smsIn"); if(ta){ ta.value = txt; document.getElementById("parseBtn").click(); } }, 900); }
  }catch(e){}

  /* first visit in Safari on iPhone: how to add Kosha to the Home Screen */
  if(isIOS && !standalone && !localStorageGet("kosha.a2hsShown")){
    setTimeout(function(){
      localStorageSet("kosha.a2hsShown", "1");
      var sc = document.createElement("div"); sc.className = "scrim";
      sc.innerHTML = '<div class="sheet kw-sheet"><h2>📲 ' + esc(T("Add Kosha to your Home Screen")) + '</h2>' +
        '<div class="kw-step"><b>1.</b><p>' + esc(T("Tap the Share button (the square with an arrow) in Safari's toolbar.")) + '</p></div>' +
        '<div class="kw-step"><b>2.</b><p>' + esc(T("Scroll down and tap Add to Home Screen, then Add.")) + '</p></div>' +
        '<div class="kw-step"><b>3.</b><p>' + esc(T("Open Kosha from the Home Screen icon from now on. Your data stays safest there.")) + '</p></div>' +
        '<div class="row" style="margin-top:12px"><button type="button" class="btn primary" data-kw="x">' + esc(T("OK")) + '</button></div></div>';
      document.body.appendChild(sc);
      sc.addEventListener("click", function(e){ if(e.target === sc || e.target.closest("[data-kw]")) sc.remove(); });
    }, 1500);
  }

  var st = document.createElement("style");
  st.textContent = ".kw-paste{position:fixed;right:16px;bottom:calc(84px + env(safe-area-inset-bottom,0px));z-index:40;display:flex;align-items:center;gap:6px;padding:11px 16px;border-radius:24px;border:0;background:var(--accent,#f39200);color:#fff;font:inherit;font-weight:600;box-shadow:0 6px 18px rgba(0,0,0,.18)}" +
    ".kw-url{font:12px/1.4 ui-monospace,Menlo,monospace;word-break:break-all;padding:10px;border:1px dashed var(--rule);border-radius:10px;user-select:all;-webkit-user-select:all}.kw-sheet .kw-step{padding:8px 0;border-bottom:1px solid var(--rule)}.kw-sheet .kw-step p{margin:3px 0 0;color:var(--muted);line-height:1.4}.kw-bk{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--rule)}";
  document.head.appendChild(st);
})();
