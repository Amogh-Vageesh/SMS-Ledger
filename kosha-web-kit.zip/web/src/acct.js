/* v1.240: tap your initial (top right) → account menu with Google sign-in / sign-out, without digging through Settings */
(function(){
  if(window.__koshaAcct) return; window.__koshaAcct = true;
  const Tr = s => { try{ return (typeof V2!=="undefined"&&V2.tr)?V2.tr(s):s; }catch(e){ return s; } };
  const E = s => String(s==null?"":s).replace(/[&<>"]/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;" }[c]));
  function me(){ try{ if(cloudUser&&cloudUser.uid) return cloudUser; }catch(e){} try{ const u=JSON.parse(window.Android&&Android.getCurrentUser?Android.getCurrentUser():"null"); if(u&&u.uid) return u; }catch(e){} return null; }
  function openMenu(){
    if(document.getElementById("kwAcct")) return;
    const u = me(), sc = document.createElement("div"); sc.className = "scrim"; sc.id = "kwAcct";
    const ini = String((u&&(u.name||u.email))||"?").trim().charAt(0).toUpperCase();
    sc.innerHTML = `<div class="sheet kw-acct"><div class="kw-acct-h"><span class="kw-acct-av">${E(ini)}</span><span><b>${E(u?(u.name||"Google account"):Tr("Not signed in"))}</b><small>${E(u?(u.email||""):Tr("Sign in to share with family and keep your data safe"))}</small></span></div>
      ${u?`<button type="button" class="btn kw-acct-b" data-ac="out">↪︎ ${Tr("Sign out of Google")}</button>`:`<button type="button" class="btn primary kw-acct-b" data-ac="in">G&nbsp; ${Tr("Sign in with Google")}</button>`}
      <button type="button" class="btn kw-acct-b" data-ac="settings">⚙️ ${Tr("Settings")}</button>
      <button type="button" class="btn kw-acct-b" data-ac="x">${Tr("Close")}</button>
      ${u?`<p class="help" style="margin-top:8px">${Tr("Signing out keeps everything on this phone. Family sharing pauses until you sign in again.")}</p>`:""}</div>`;
    document.body.appendChild(sc);
    sc.addEventListener("click", e => {
      const b = e.target.closest("[data-ac]"); if(e.target===sc || (b&&b.dataset.ac==="x")){ sc.remove(); return; } if(!b) return;
      if(b.dataset.ac==="settings"){ sc.remove(); try{ view="settings"; window.scrollTo(0,0); render(); }catch(err){} return; }
      if(b.dataset.ac==="in"){ sc.remove(); try{ Android.signIn(); }catch(err){ toast(Tr("Sign-in isn't available here.")); } return; }
      if(b.dataset.ac==="out"){ if(!b.dataset.armed){ b.dataset.armed="1"; b.textContent=Tr("Tap again to sign out"); b.classList.add("danger"); return; }
        sc.remove(); try{ Android.signOutCloud(); }catch(err){} try{ cloudUser=null; }catch(err){} setTimeout(()=>{ try{ render(); }catch(err){} }, 400); }
    });
  }
  document.addEventListener("click", e => { const b = e.target.closest(".v2-me"); if(!b) return; e.preventDefault(); e.stopImmediatePropagation(); openMenu(); }, true);
  window.koshaAccountMenu = openMenu;
  const st=document.createElement("style"); st.textContent=".kw-acct-h{display:flex;gap:12px;align-items:center;margin:2px 0 14px}.kw-acct-h small{display:block;color:var(--muted);margin-top:2px;word-break:break-all}.kw-acct-av{width:46px;height:46px;border-radius:50%;display:grid;place-items:center;background:#5b5bd6;color:#fff;font-weight:700;font-size:1.2em;flex:none}.kw-acct-b{display:block;width:100%;margin:6px 0;text-align:left}.kw-acct-b.danger{color:#c0392b;border-color:#c0392b}"; document.head.appendChild(st);
})();
